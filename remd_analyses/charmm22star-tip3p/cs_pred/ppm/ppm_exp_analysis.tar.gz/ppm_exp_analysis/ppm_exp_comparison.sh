source /usr/local/envs/py37/bin/activate
#creates reference
path_traj=../../../traj6_fix.xtc
path_tpr=../../../topol6_prot.tpr
#copy locally the file with the reference experimental chemical shift
cp ../../../../../cs_gary/conversion/AT3_cs_gary .

echo "10\n"|gmx trjconv -f ${path_traj} -s ${path_tpr} -n index -b 0 -e 0 -o reference.pdb




for bmrbentry in AT3_cs_gary ; 
do
for i in 0 5 10 15 20 25 30 35 40 45 50 ; do
	mkdir ${i}_ns_${bmrbentry}
	cd ${i}_ns_${bmrbentry}
	cp ../delta_CS.py .
	cp -r ../aux_files .
        pwd 

	if [  ${i} = 50 ] 
	then	
        python delta_CS.py -exp ../$bmrbentry -bp ../../ppm_results/ppm_${i}/bmrb_pre.dat  -ref ../reference.pdb -pdb_mapping yes -histograms yes
	else
	echo "not 50"
        python delta_CS.py -exp ../$bmrbentry -bp ../../ppm_results/ppm_${i}/bmrb_pre.dat  -ref ../reference.pdb -pdb_mapping no -histograms no
	fi

	rm ./CS_compare.py 
	rm ./output_*
	rm ./reference_*	
	rm -r ./aux_files
        cd ..
done
done
#-ch3 ..:/ch3shift/out_ch3shift_${i}.

rm ./#*
