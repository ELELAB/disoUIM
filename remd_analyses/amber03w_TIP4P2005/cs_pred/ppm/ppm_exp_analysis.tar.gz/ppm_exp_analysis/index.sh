
echo "r 2-55\nq\n"|gmx make_ndx -f ../../../topol6_prot.tpr
