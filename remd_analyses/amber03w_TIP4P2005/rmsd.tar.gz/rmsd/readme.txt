We here calculated the rmsd of the mainchain atoms of the AT3 3UIM region including residues E336-T350 to the starting structures of AT-3 UIM3 
We performed this analysis on the REMD simulation considering the trajectory at 304 K
#For the At3 3UIM we used for the alignment and the calculations the heavy atoms of residue E336-T350 and the side chain heavy atoms of A343

#We calculated the alignment and the rmsd by an in-house python scripts using MDAnalysis, matplotlib, and pandas toolkits 
#To reproduce this analysis run the script rmsd.sh

