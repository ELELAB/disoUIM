VAR="$(awk -v c=2 -v t=0.44 '{a[NR]=$c}END{
        asort(a);d=a[NR]-t;d=d<0?-d:d;v = a[NR]
        for(i=NR-1;i>=1;i--){
                m=a[i]-t;m=m<0?-m:m
                if(m<d){
                    d=m;v=a[i]
                }
        }
        print v
}' rmsd_31-45_mainchain.xvg)"

echo "$VAR"
awk -v a="$VAR" '$2==a {print $1}' rmsd_31-45_mainchain.xvg
