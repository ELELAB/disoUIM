
#!/bin/bash
path_traj=../../../traj6_fix.xtc
path_tpr=../../../topol6_prot.tpr

#creates index file.
echo "r 2-55\nq\n"|gmx  make_ndx -f ${path_tpr}


#pipeline: runs ppm for the substractories 0, 25, 50, ..., 1000 ns and ch3shift only for the complete trajectory (1000 ns)
for e in 0 5 10 15 20 25 30 35 40 45 50

do
echo "10\n"|gmx  trjconv -f ${path_traj} -s ${path_tpr} -b 0 -e ${e}000 -skip 10 -o traj_$e.pdb -n index.ndx #no_capping


###################################################
############            PPM           ############
##################################################


mkdir ppm_${e}
cd ppm_${e}
echo Starting with ppm calculations ... 
../ppm_stable -pdb ../traj_${e}.pdb #> ppm_${e}_output.log &

 # However, it does not work when the sequences are not identical. It did not work with our trajs. 

echo Done with PPM for t=$e ns ...
cd ..

rm ./#*
#remove trajectory
echo Removing created trajectory ... 
rm traj_${e}.pdb

done



