import MDAnalysis as mda
import matplotlib.pyplot as plt
from MDAnalysis.analysis import align
from MDAnalysis.analysis import rms
import pandas as pd
x = mda.Universe('1Q0W_clean_AB_filt.pdb')
a = mda.Universe('traj6_fix_filt.pdb')
align.AlignTraj(a,x,select='backbone or (resid 8 and name CB and resname ALA)',filename='aligned_1q0w.pdb',match_atoms=True,dt=16).run()
R = rms.RMSD(a,x,select='backbone or (resid 8 and name CB and resname ALA)')
R.run()
df = pd.DataFrame(R.rmsd,columns=['Frames','Time (ns)','backbone or (resid 8 and name CB and resname ALA)'])
df.to_csv('rmsd_1q0w.csv', index=False)
fig = df.plot(x='Frames', y=['backbone or (resid 8 and name CB and resname ALA)'],kind='hist', figsize=(20, 16), fontsize=26, color=['#404788FF'], edgecolor="black", legend=False)
fig.set_xlabel(r'RMSD ($\AA$)')
for item in ([fig.title, fig.xaxis.label, fig.yaxis.label] +
             fig.get_xticklabels() + fig.get_yticklabels()):
    item.set_fontsize(20)
fig.figure.savefig('rmsd_1q0w.pdf')
