We here calculated the rmsd of the mainchain atoms of the AT3 3UIM region including residues E336-T350 to the experimental structures of bound UIMs 
We performed this analysis on the charmm22star-tips3p REMD simulation considering the trajectory at 304 K
#For the At3 3UIM we used for the alignment and the calculations the heavy atoms of residue E336-T350 and the side chain heavy atoms of A343
#For the 1Q0W Solution structure of Vps27 amino-terminal UIM-ubiquitin complex we used for the alignment and the calculations the heavy atoms of residue E259-E273 and the side chain heavy atoms of A266
#For the 1YX5 Solution Structure of S5a UIM-1/Ubiquitin Complex we used for the alignment and the calculations the heavy atoms of residue A212-E226 and the side chain heavy atoms of A219
#For the 1YX6 Solution Structure of S5a UIM-2/Ubiquitin Complex we used for the alignment and the calculations the heavy atoms of residue E283-G297 and the side chain heavy atoms of A290
#For the 3A1Q Crystal structure of the mouse RAP80 UIMs in complex with Lys63-linked di-ubiquitin UIM1 we used for the alignment and the calculations the heavy atoms of residue E81-E95 and the side chain heavy atoms of A88


#We calculated the alignment and the rmsd by an in-house python scripts using MDAnalysis, matplotlib, and pandas toolkits 

#generate index for the AT3 3UIM
gmx_mpi make_ndx -f ../../charmm22star-tips3p/topol6_prot.tpr -o index.3UIM.ndx <<eof
a N CA C O
r 31-45  
10 & 11
r 38 & a CB     
12 | 13
q
eof

#filter the trajectory of AT3 3UIM in pdb format
gmx_mpi trjconv -f ../../charmm22star-tips3p/traj6_fix.xtc -s ../../charmm22star-tips3p/topol6_prot.tpr -o traj6_fix_filt.pdb -n index.3UIM.ndx <<eof
14
eof

##############################
#analysis for rmsd to 1Q0W
cp ../../../pdbs/pdbs_processed/split_chain/1Q0W_clean_AB.pdb .

gmx_mpi make_ndx -f 1Q0W_clean_AB.pdb -o index.1Q0W.ndx  <<eof
a N CA C O
r 259-273
10 & 11
r 266 & a CB
12 | 13
q
eof

#filter the pdb
gmx_mpi trjconv -f 1Q0W_clean_AB.pdb -s 1Q0W_clean_AB.pdb -o 1Q0W_clean_AB_filt.pdb -n index.1Q0W.ndx <<eof
14
eof

#run the script for analysis of rmsd and plotting
python3 rmsd_1q0w.py

##############################
#analysis for rmsd to 1YX5
cp ../../../pdbs/pdbs_processed/split_chain/1YX5_clean_AB.pdb .

gmx_mpi make_ndx -f 1YX5_clean_AB.pdb -o index.1YX5.ndx  <<eof
a N CA C O
ri 18-32
10 & 11
ri 25 & a CB
12 | 13
q
eof

#filter the pdb
gmx_mpi trjconv -f 1YX5_clean_AB.pdb -s 1YX5_clean_AB.pdb -o 1YX5_clean_AB_filt.pdb -n index.1YX5.ndx <<eof
14
eof

#run the script for analysis of rmsd and plotting
python3 rmsd_1yx5.py

##############################
#analysis for rmsd to 1YX6
cp ../../../pdbs/pdbs_processed/split_chain/1YX6_clean_AB.pdb .

gmx_mpi make_ndx -f 1YX6_clean_AB.pdb -o index.1YX6.ndx  <<eof
a N CA C O
ri 89-103
10 & 11
ri 96 & a CB
12 | 13
q
eof

#filter the pdb
gmx_mpi trjconv -f 1YX6_clean_AB.pdb -s 1YX6_clean_AB.pdb -o 1YX6_clean_AB_filt.pdb -n index.1YX6.ndx <<eof
14
eof

#run the script for analysis of rmsd and plotting
python3 rmsd_1yx6.py

##############################
#analysis for rmsd to 3A1Q
cp ../../../pdbs/pdbs_processed/split_chain/3A1Q_clean_ABC.pdb .

gmx_mpi make_ndx -f 3A1Q_clean_ABC.pdb -o index.3A1Q.ndx  <<eof
a N CA C O
ri 154-168
10 & 11
ri 161 & a CB
12 | 13
q
eof

#filter the pdb
gmx_mpi trjconv -f 3A1Q_clean_ABC.pdb -s 3A1Q_clean_ABC.pdb -o 3A1Q_clean_ABC_filt.pdb -n index.3A1Q.ndx <<eof
14
eof

#run the script for analysis of rmsd and plotting
python3 rmsd_3a1q.py

#we prepared teh final panels in pymol shoeing
#frame 1990 of AT3 3UIM for 1Q0W saved in the session 1Q0W.pse
#frame  502 of AT3 3UIM for 1YX5 saved in the session 1YX5.pse
#frame 1021 of AT3 3UIM for 1YX6 saved in the session 1YX6.pse
#frame  191 of AT3 3UIM for 3A1Q saved in the session 3A1Q.pse


