#generate index for the AT3 3UIM
gmx_mpi make_ndx -f ../topol6_prot.tpr -o index.3UIM.ndx <<eof
a N CA C O
r 31-45  
10 & 11
r 38 & a CB     
12 | 13
q
eof

#filter the trajectory of AT3 3UIM in pdb format
gmx_mpi trjconv -f ../traj6_fix.xtc -s ../topol6_prot.tpr -o traj6_fix_filt.pdb -n index.3UIM.ndx <<eof
14
eof

##############################
#analysis for rmsd to starting structure for REMD simulations  of AT-3 UIM3
cp ../../AT3_3UIM_model1.B99990004.pdb .

gmx_mpi make_ndx -f AT3_3UIM_model1.B99990004.pdb -o index.AT3.ndx  <<eof
a N CA C O
ri 31-45
10 & 11
ri 38 & a CB
12 | 13
q
eof

#we filtered the pdb
gmx_mpi trjconv -f AT3_3UIM_model1.B99990004.pdb -s AT3_3UIM_model1.B99990004.pdb -o AT3_3UIM_model1.B99990004_filt.pdb -n index.AT3.ndx <<eof
14
eof

#run the script for analysis of rmsd and plotting
python3 rmsd_AT3.py



