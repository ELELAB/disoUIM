#Here we include the files to reproduce the WT-metaD simulations associated with the publication Ubiquitin Interacting Motifs: duality between structured and disordered motifs Lambrughi, Papaleo et. al.

#These files are deposited in plumed-nest
