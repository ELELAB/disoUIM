run the R script to obtain: i) the plot of the monodimensional free energy surface using the alphabeta values converted in kcal/mol, ii) the plot of the monodimensional free energy surface using the alphabeta values converted in kcal/mol with dashed lines defining ranges of values selected to extract conformations with driver2

