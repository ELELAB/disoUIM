library(ggplot2)
library(ggpubr)
library(dplyr)

#ff03w
df <- read.table("fes.a032005.dat", header=FALSE)
df03w <- df %>% mutate(V3 = V2 - min(V2))
df03w$V3 <- as.numeric(as.character(df03w$V3)) / 4.184
colnames(df03w) <- c("ab","ener_kj","ener_kcal")
#ff03ws
df2 <- read.table("fes.a03ws.dat", header=FALSE)
df03ws <- df2 %>% mutate(V3 = V2 - min(V2))
df03ws$V3 <- as.numeric(as.character(df03ws$V3)) / 4.184
colnames(df03ws) <- c("ab","ener_kj","ener_kcal")
#CHARMM22*2
df3 <- read.table("fes.c22st.dat", header=FALSE)
df22st <- df3 %>% mutate(V3 = V2 - min(V2))
df22st$V3 <- as.numeric(as.character(df22st$V3)) / 4.184
colnames(df22st) <- c("ab","ener_kj","ener_kcal")

p <- ggplot() +
  geom_line(data = df03w, aes(x=ab, y=ener_kcal), color="#E69F00", size=1.5, alpha=0.9) +
  ggtitle("") +
  geom_line(data = df03ws, aes(x=ab, y=ener_kcal), color="#56B4E9", size=1.5, alpha=0.9) +
  geom_line(data = df22st, aes(x=ab, y=ener_kcal), color="#cc79a7", size=1.5, alpha=0.9) +
  #geom_line(data = df4, aes(x=res_num, y=Prob), color="#404788FF", size=1.5, alpha=0.9) +
  xlab("alphabeta") + ylab("free energy (kcal/mol)") +  
  scale_x_continuous(limits = c(0, 50), expand = c(0, 0)) +
  scale_y_continuous( expand = c(0, 0)) +
  #geom_hline(yintercept=0.50, linetype="dashed") +
  theme (panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"), axis.title.x = element_text(size = rel(2)), axis.title.y = element_text(size = rel(2)), axis.text=element_text(size= rel(2)), legend.text = element_text(size = rel(1.5)), legend.title = element_text(size = rel(2)))
ggsave("1D_FES_ab.pdf",p, width=10, height=10, units="in", scale=0.8)

################################


#ff03w
df <- read.table("fes.a032005.dat", header=FALSE)
df03w <- df %>% mutate(V3 = V2 - min(V2))
df03w$V3 <- as.numeric(as.character(df03w$V3)) / 4.184
colnames(df03w) <- c("ab","ener_kj","ener_kcal")
#ff03ws
df2 <- read.table("fes.a03ws.dat", header=FALSE)
df03ws <- df2 %>% mutate(V3 = V2 - min(V2))
df03ws$V3 <- as.numeric(as.character(df03ws$V3)) / 4.184
colnames(df03ws) <- c("ab","ener_kj","ener_kcal")
#CHARMM22*2
df3 <- read.table("fes.c22st.dat", header=FALSE)
df22st <- df3 %>% mutate(V3 = V2 - min(V2))
df22st$V3 <- as.numeric(as.character(df22st$V3)) / 4.184
colnames(df22st) <- c("ab","ener_kj","ener_kcal")

p <- ggplot() +
  geom_line(data = df03w, aes(x=ab, y=ener_kcal), color="#E69F00", size=1.5, alpha=0.9) +
  ggtitle("") +
  geom_line(data = df03ws, aes(x=ab, y=ener_kcal), color="#56B4E9", size=1.5, alpha=0.9) +
  geom_line(data = df22st, aes(x=ab, y=ener_kcal), color="#cc79a7", size=1.5, alpha=0.9) +
  #geom_line(data = df4, aes(x=res_num, y=Prob), color="#404788FF", size=1.5, alpha=0.9) +
  xlab("alphabeta") + ylab("free energy (kcal/mol)") +  
  scale_x_continuous(limits = c(0, 50), expand = c(0, 0)) +
  scale_y_continuous( expand = c(0, 0)) +
  geom_vline(xintercept = 9, color="grey", 
             linetype="dashed", size=0.5) +
  geom_vline(xintercept = 17, color="grey", 
             linetype="dashed", size=0.5) + 
  geom_vline(xintercept = 18, color="grey", 
             linetype="dashed", size=0.5) +
  geom_vline(xintercept = 23, color="grey", 
             linetype="dashed", size=0.5) +
  geom_vline(xintercept = 24, color="grey", 
             linetype="dashed", size=0.5) +
  geom_vline(xintercept = 30, color="grey", 
             linetype="dashed", size=0.5) +
  geom_vline(xintercept = 31, color="grey", 
             linetype="dashed", size=0.5) +
  geom_vline(xintercept = 34, color="grey", 
             linetype="dashed", size=0.5) +
  #geom_hline(yintercept=0.50, linetype="dashed") +
  theme (panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"), axis.title.x = element_text(size = rel(2)), axis.title.y = element_text(size = rel(2)), axis.text=element_text(size= rel(2)), legend.text = element_text(size = rel(1.5)), legend.title = element_text(size = rel(2)))

ggsave("1D_FES_ab_dash.pdf",p, width=10, height=10, units="in", scale=0.8)

################################
