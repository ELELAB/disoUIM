#
cat ../fileI.gro ../fileII.gro > parz
cat parz ../fileIII.gro > parz2
cat parz2 ../fileIV.gro > file_all.gro
rm parz parz2

export DSSP=/usr/local/dssp-3.0.10/bin/mkdssp
gmx_mpi do_dssp -f ../fileI.gro -s sim.prot.tpr -sc scountI.xvg -o ssI.xpm <<eof
1
eof
gmx_mpi do_dssp -f ../fileII.gro -s sim.prot.tpr -sc scountII.xvg -o ssII.xpm <<eof
1
eof
gmx_mpi do_dssp -f ../fileIII.gro -s sim.prot.tpr -sc scountIII.xvg -o ssIII.xpm <<eof
1
eof
gmx_mpi do_dssp -f ../fileIV.gro -s sim.prot.tpr -sc scountIV.xvg -o ssIV.xpm <<eof
1
eof
gmx_mpi do_dssp -f file_all.gro -s sim.prot.tpr -sc scount_all.xvg -o ss_all.xpm <<eof
1
eof

#remove the header and the comma from the xpm files
sed -i '\~/~d' ssI.xpm
sed -i 's/,//g'  ssI.xpm
sed -i '\~/~d' ssII.xpm
sed -i 's/,//g'  ssII.xpm
sed -i '\~/~d' ssIII.xpm
sed -i 's/,//g'  ssIII.xpm
sed -i '\~/~d' ssIV.xpm
sed -i 's/,//g'  ssIV.xpm
sed -i '\~/~d' ss_all.xpm
sed -i 's/,//g'  ss_all.xpm


#run the dssp.R script for the plotting
