#make line plot from dssp gromacs output .xpm file.
# the dssp.xpm file needs to be clean by deleting the header lines till the first data line "~~~~SSCC" and also the commas at the end of each data line
# the file should contain only the dssp values  "~~~SS"
#install.packages("MDplot")

library(MDplot)
library(tidyr)
#####I######
dssp_inputI = read.table("ssI.xpm", header = FALSE, fill = TRUE)
dssp_inputI$V2 <- NULL
system_ref <- "AT-3_UIM3"
## the xpm format has a reversed order of lines, so the first line is actually the last residue
## to convert it
dssp_orderI<-as.data.frame(dssp_inputI[nrow(dssp_inputI)[1]:1,])
## to sparate the characters and transpose matrix
out <- do.call(cbind, apply(dssp_orderI, 1, function(x) data.frame(strsplit(as.character(x), ""))))
## Select the residues to plot
out_at3I <- out[,c(1:55)]
## Combine characters together in single row
out_at3I_done <- data.frame(apply(out_at3I, 1, paste, collapse=""))
## Write output file that can be loaded with load_dssp function
write.table (out_at3I_done, file="dssp_I.txt",  row.names = FALSE, col.names = FALSE, quote = FALSE)

#####II######
dssp_inputII = read.table("ssII.xpm", header = FALSE, fill = TRUE)
dssp_inputII$V2 <- NULL
system_ref <- "AT-3_UIM3"
## the xpm format has a reversed order of lines, so the first line is actually the last residue
## to convert it
dssp_orderII<-as.data.frame(dssp_inputII[nrow(dssp_inputII)[1]:1,])
## to sparate the characters and transpose matrix
out <- do.call(cbind, apply(dssp_orderII, 1, function(x) data.frame(strsplit(as.character(x), ""))))
## Select the residues to plot
out_at3II <- out[,c(1:55)]
## Combine characters together in single row
out_at3II_done <- data.frame(apply(out_at3II, 1, paste, collapse=""))
## Write output file that can be loaded with load_dssp function
write.table (out_at3II_done, file="dssp_II.txt",  row.names = FALSE, col.names = FALSE, quote = FALSE)

#####III######
dssp_inputIII = read.table("ssIII.xpm", header = FALSE, fill = TRUE)
dssp_inputIII$V2 <- NULL
system_ref <- "AT-3_UIM3"
## the xpm format has a reversed order of lines, so the first line is actually the last residue
## to convert it
dssp_orderIII<-as.data.frame(dssp_inputIII[nrow(dssp_inputIII)[1]:1,])
## to sparate the characters and transpose matrix
out <- do.call(cbind, apply(dssp_orderIII, 1, function(x) data.frame(strsplit(as.character(x), ""))))
## Select the residues to plot
out_at3III <- out[,c(1:55)]
## Combine characters together in single row
out_at3III_done <- data.frame(apply(out_at3III, 1, paste, collapse=""))
## Write output file that can be loaded with load_dssp function
write.table (out_at3III_done, file="dssp_III.txt",  row.names = FALSE, col.names = FALSE, quote = FALSE)

#####IV######
dssp_inputIV = read.table("ssIV.xpm", header = FALSE, fill = TRUE)
dssp_inputIV$V2 <- NULL
system_ref <- "AT-3_UIM3"
## the xpm format has a reversed order of lines, so the first line is actually the last residue
## to convert it
dssp_orderIV<-as.data.frame(dssp_inputIV[nrow(dssp_inputIV)[1]:1,])
## to sparate the characters and transpose matrix
out <- do.call(cbind, apply(dssp_orderIV, 1, function(x) data.frame(strsplit(as.character(x), ""))))
## Select the residues to plot
out_at3IV <- out[,c(1:55)]
## Combine characters together in single row
out_at3IV_done <- data.frame(apply(out_at3IV, 1, paste, collapse=""))
## Write output file that can be loaded with load_dssp function
write.table (out_at3IV_done, file="dssp_IV.txt",  row.names = FALSE, col.names = FALSE, quote = FALSE)

#####all######
dssp_inputall = read.table("ss_all.xpm", header = FALSE, fill = TRUE)
dssp_inputall$V2 <- NULL
system_ref <- "AT-3_UIM3"
## the xpm format has a reversed order of lines, so the first line is actually the last residue
## to convert it
dssp_orderall<-as.data.frame(dssp_inputall[nrow(dssp_inputall)[1]:1,])
## to sparate the characters and transpose matrix
out <- do.call(cbind, apply(dssp_orderall, 1, function(x) data.frame(strsplit(as.character(x), ""))))
## Select the residues to plot
out_at3all <- out[,c(1:55)]
## Combine characters together in single row
out_at3all_done <- data.frame(apply(out_at3all, 1, paste, collapse=""))
## Write output file that can be loaded with load_dssp function
write.table (out_at3all_done, file="dssp_all.txt",  row.names = FALSE, col.names = FALSE, quote = FALSE)

dsspI <- load_dssp("dssp_I.txt", mdEngine = "GROMACS")
dsspI.df <- as.data.frame(dsspI)
library(tidyverse)
dsspI.df2 <- dsspI.df %>% select(residue,`4-Helix`,`5-Helix`,`3-Helix`)
#dsspI.df2$residue <- seq.int(nrow(dsspI.df2))
dsspI.df2$residue <- dsspI.df2$residue + 305
library(tidyr)
dsspI.df2.long <- dsspI.df2 %>% gather(ss, occurence, -c(residue))
p <- ggplot() +
  geom_line(data = dsspI.df2.long, aes(x=residue, y=occurence, color=ss), size=1.5, alpha=0.9) +
  ggtitle("") +
  xlab("residue") + ylab("occurence (%)") +  
  #scale_x_continuous(limits = c(306, 5), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 100), expand = c(0, 0)) +
  #geom_hline(yintercept=0.50, linetype="dashed") +
  theme (panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"), axis.title.x = element_text(size = rel(2)), axis.title.y = element_text(size = rel(2)), axis.text=element_text(size= rel(2)), legend.text = element_text(size = rel(1.5)), legend.title = element_text(size = rel(2)))
ggsave("dssp_helix_I.pdf",p, width=10, height=10, units="in", scale=0.8)


dsspII <- load_dssp("dssp_II.txt", mdEngine = "GROMACS")
dsspII.df <- as.data.frame(dsspII)
library(tidyverse)
dsspII.df2 <- dsspII.df %>% select(residue,`4-Helix`,`5-Helix`,`3-Helix`)
#dsspI.df2$residue <- seq.int(nrow(dsspI.df2))
dsspII.df2$residue <- dsspII.df2$residue + 305
library(tidyr)
dsspII.df2.long <- dsspII.df2 %>% gather(ss, occurence, -c(residue))
p <- ggplot() +
  geom_line(data = dsspII.df2.long, aes(x=residue, y=occurence, color=ss), size=1.5, alpha=0.9) +
  ggtitle("") +
  xlab("residue") + ylab("occurence (%)") +  
  #scale_x_continuous(limits = c(306, 5), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 100), expand = c(0, 0)) +
  #geom_hline(yintercept=0.50, linetype="dashed") +
  theme (panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"), axis.title.x = element_text(size = rel(2)), axis.title.y = element_text(size = rel(2)), axis.text=element_text(size= rel(2)), legend.text = element_text(size = rel(1.5)), legend.title = element_text(size = rel(2)))
ggsave("dssp_helix_II.pdf",p, width=10, height=10, units="in", scale=0.8)

dsspIII <- load_dssp("dssp_III.txt", mdEngine = "GROMACS")
dsspIII.df <- as.data.frame(dsspIII)
library(tidyverse)
dsspIII.df2 <- dsspIII.df %>% select(residue,`4-Helix`,`5-Helix`,`3-Helix`)
#dsspI.df2$residue <- seq.int(nrow(dsspI.df2))
dsspIII.df2$residue <- dsspIII.df2$residue + 305
library(tidyr)
dsspIII.df2.long <- dsspIII.df2 %>% gather(ss, occurence, -c(residue))
p <- ggplot() +
  geom_line(data = dsspIII.df2.long, aes(x=residue, y=occurence, color=ss), size=1.5, alpha=0.9) +
  ggtitle("") +
  xlab("residue") + ylab("occurence (%)") +  
  #scale_x_continuous(limits = c(306, 5), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 100), expand = c(0, 0)) +
  #geom_hline(yintercept=0.50, linetype="dashed") +
  theme (panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"), axis.title.x = element_text(size = rel(2)), axis.title.y = element_text(size = rel(2)), axis.text=element_text(size= rel(2)), legend.text = element_text(size = rel(1.5)), legend.title = element_text(size = rel(2)))
ggsave("dssp_helix_III.pdf",p, width=10, height=10, units="in", scale=0.8)

dsspIV <- load_dssp("dssp_IV.txt", mdEngine = "GROMACS")
dsspIV.df <- as.data.frame(dsspIV)
library(tidyverse)
dsspIV.df2 <- dsspIV.df %>% select(residue,`4-Helix`,`5-Helix`,`3-Helix`)
#dsspI.df2$residue <- seq.int(nrow(dsspI.df2))
dsspIV.df2$residue <- dsspIV.df2$residue + 305
library(tidyr)
dsspIV.df2.long <- dsspIV.df2 %>% gather(ss, occurence, -c(residue))
p <- ggplot() +
  geom_line(data = dsspIV.df2.long, aes(x=residue, y=occurence, color=ss), size=1.5, alpha=0.9) +
  ggtitle("") +
  xlab("residue") + ylab("occurence (%)") +  
  #scale_x_continuous(limits = c(306, 5), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 100), expand = c(0, 0)) +
  #geom_hline(yintercept=0.50, linetype="dashed") +
  theme (panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"), axis.title.x = element_text(size = rel(2)), axis.title.y = element_text(size = rel(2)), axis.text=element_text(size= rel(2)), legend.text = element_text(size = rel(1.5)), legend.title = element_text(size = rel(2)))
ggsave("dssp_helix_IV.pdf",p, width=10, height=10, units="in", scale=0.8)

dsspall <- load_dssp("dssp_all.txt", mdEngine = "GROMACS")
dsspall.df <- as.data.frame(dsspall)
library(tidyverse)
dsspall.df2 <- dsspall.df %>% select(residue,`4-Helix`,`5-Helix`,`3-Helix`)
#dsspI.df2$residue <- seq.int(nrow(dsspI.df2))
dsspall.df2$residue <- dsspall.df2$residue + 305
library(tidyr)
dsspall.df2.long <- dsspall.df2 %>% gather(ss, occurence, -c(residue))
p <- ggplot() +
  geom_line(data = dsspall.df2.long, aes(x=residue, y=occurence, color=ss), size=1.5, alpha=0.9) +
  ggtitle("") +
  xlab("residue") + ylab("occurence (%)") +  
  #scale_x_continuous(limits = c(306, 5), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 100), expand = c(0, 0)) +
  #geom_hline(yintercept=0.50, linetype="dashed") +
  theme (panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"), axis.title.x = element_text(size = rel(2)), axis.title.y = element_text(size = rel(2)), axis.text=element_text(size= rel(2)), legend.text = element_text(size = rel(1.5)), legend.title = element_text(size = rel(2)))
ggsave("dssp_helix_all.pdf",p, width=10, height=10, units="in", scale=0.8)
