#We here calculated the DSSP analysis on the four ensemble and their combination extracted with driver from WTE-metadynamics using four ranges of alphabeta values
To reproduce the analysis run the bash script run.sh
