cvnum=1
hillsfile=HILLS
totcvs=2
stride=50000
nproc=4
mpirun -np $nproc /usr/local/sum_hills/parallel/sum_hills_mpi.x -f $hillsfile -out fes.dat -stride $stride -ndim $totcvs -ndw $cvnum -kt 2.5 
