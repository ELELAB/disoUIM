python ludo-matplot.py fes.dat 150 150 -min0 -out cv1_vs_cv2.pdf -xlab 'Rg(nm)' -ylab 'helical content' -kcal
python ludo-matplot.py fes.dat.623 150 150 -min0 -out cv1_vs_cv2_623.pdf -xlab 'Rg(nm)' -ylab 'helical content' -kcal
python ludo-matplot.py fes.dat.100 150 150 -min0 -out cv1_vs_cv2_100.pdf -xlab 'Rg(nm)' -ylab 'helical content' -kcal
