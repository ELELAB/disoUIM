import MetaD_analysis
import glob

"""This is an example script using the MetaD_analysis script."""

#Manually input the fes you want to plot on top of each other
filelist = ["fes_0.dat","fes_1.dat","fes_2.dat"] 

#Or use a unix pattern to find all files with that pattern
pattern = "./fes_*.dat"

#Use glob to find the files and sort the list of files naturally so 10 is after 2 ect.
filelist2 = sorted(glob.glob(pattern),key=MetaD_analysis.natural_sort_key)  

#Make a plotter object with 1 plot
aplotter = MetaD_analysis.Plotter(1)

#Plot "filelist" as a 1D fes with title "First FES" and a time of x ps
aplotter.oneDfesplot(filelist,"First FES",time = 600000)

#Show the plot
aplotter.show()

#Write as pdf
aplotter.writePdf("Filename.pdf")

#A 2D fes is plotted like this:

#First a list of FES
twoDfilelist = ["./2D_fes/fes_0.dat","./2D_fes/fes_1.dat"]

#Then we create a different plotter
a2Dplot = MetaD_analysis.Plotter(1)

#We plot it with the 2D plot
a2Dplot.twoDfesplot(twoDfilelist)

#And Show it
a2Dplot.show()
