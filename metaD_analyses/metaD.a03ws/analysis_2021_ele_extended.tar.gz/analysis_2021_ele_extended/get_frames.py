#!/usr/bin/env python
#by Fabio
import subprocess as sp
import argparse
parser = argparse.ArgumentParser(description=
"""
Converte i file pdb ottenuti con driver in formato xtc.
Inserire i pdb da convertire, uno dopo l'altro, dopo la flag -p
""")
parser.add_argument("-f", metavar="xtc", required=True, help=
				"xtc trajectory file")
parser.add_argument("-s", metavar="gro", required=True, help=
				"gro file (without waters)")
parser.add_argument("-p", metavar="pdb", required=True, nargs='*', help=
				"pdb files to be converted")
args = parser.parse_args()

for pdb in args.p:
    with open(pdb) as corrupted_pdb:
        frames = []
        for line in corrupted_pdb:
            if 'FRAME' in line:
                frames.append(line)
        frame_numbers = [ line.split()[4] for line in frames ]
    with open(pdb[:-4] + '.ndx', 'w') as index_file:
        linea = '[ {0:} ]\n'.format(pdb[:-4])
        index_file.write(linea)
        for i, frame in enumerate(frame_numbers):
            form = '{0:}' 
            index_file.write(form.format(frame))
            if (i+1) % 15 == 0:
                index_file.write('\n')
            else:
                index_file.write(' ')
        index_file.write('\n')

ndx_files = [ pdb[:-4] + '.ndx' for pdb in args.p ]
for ndx in ndx_files:
    comando = 'trjconv -f {0} -o {1}.xtc -s {2} -fr {1}.ndx'
    sp.call(comando.format(args.f, ndx[:-4], args.s), shell=True)

