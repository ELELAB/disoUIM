#!/usr/bin/python
# Ludo 19/11/2012
# v1.2

import numpy as np
from matplotlib.mlab import griddata  #griglia di punti come funzione di x e y
from matplotlib.ticker import MaxNLocator
import matplotlib.pyplot as plt
import argparse

parser = argparse.ArgumentParser(description="Plot 2D Free Energy")
parser.add_argument("fes",help="name of the fes file", default="fes.dat")
parser.add_argument("xgrid",type=int,help="number of x values", default=200)
parser.add_argument("ygrid",type=int,help="number of y values", default=200)
parser.add_argument("-lim", nargs=4, type=float, help="x/y range")
parser.add_argument("-tit", help="title")
parser.add_argument("-xlab", help="x label")
parser.add_argument("-ylab", help="y label")
parser.add_argument("-ixy", nargs='?',const=1,help="invert x/y axes")
parser.add_argument("-noshow", nargs='?',const=1,help="if set only save file, do not show figure")
parser.add_argument("-kcal", nargs='?',const=1,help="if set, the FE is assumed in kcal/mol (contourline very 0.6) otherwise kJ/mol (contour every 5)")
parser.add_argument("-min0", nargs='?',const=1,help="shift the free enrgy with minimum in 0")
parser.add_argument("-maxf", type=float,help="set the maximum value for F")
parser.add_argument("-out", help="output pdf file")
args = parser.parse_args()

# Usage example:
# ludo-matplot.py fes.dat 150 150 -ixy -min0 -maxf 50 -lim 0 20 -10 30 -out fes.pdf

###############################################################
# Other options

# draw cbar (set False if not)
cbar_draw = True
#cbar_draw = False

if args.kcal:
    # color bar ticks
    cbar_ticks = 1
    # color bar label
    cbar_label = 'Free Energy [kcal/mol]'
    # draw contour line every
    cnt_level = 1

else:
    # color bar ticks
    cbar_ticks = 5
    # color bar label
    cbar_label = 'Free Energy [kJ/mol]'
    # draw contour line every
    cnt_level = 5

# draw value of F on the contour lines
cnt_label = True

# Choose the colormap
# help(plt.cm) to see more
# e.g.:
# plt.cm.RdYlBu
# plt.cm.jet
colormap = plt.cm.RdYlBu

# draw grid
draw_grid = True

# label, title and tick fontsize
fsize = 16
tickfsize = 14
###############################################################


x = []
y = []
z = []

#Recupero i dati
fes = open(args.fes)
for line in fes:
	if line == '\n':pass
	else:
		dati=line.split()
		if not dati:pass
		else:
			if args.ixy: 
				# invert axis
				x.append(float(dati[1]))
				y.append(float(dati[0]))
			else:
	#			print dati[0],dati[1]
				x.append(float(dati[0]))
				y.append(float(dati[1]))
			z.append(float(dati[2]))


# NB XXXXXXXXXXX WARNING ADHOC SOLUTION: ASSUMES FES IN KJOULE AND OUTPUTS IN KCAL
# convert from kJ/mol to kCal/mol
z = map(lambda a: a*0.239,z )

if args.min0:
	# shifts all the F values so that minimum is 0 (and they are all positives)
	minz = min(z)
	z = map(lambda a: a - minz,z ) 

minz = min(z)

if args.lim:
	x1 = np.linspace(args.lim[0],args.lim[1], args.xgrid)
	y1 = np.linspace(args.lim[2],args.lim[3], args.ygrid) 
else:
	x1 = np.linspace(x[0],x[len(x)-1], args.xgrid)
	y1 = np.linspace(y[0],y[len(y)-1], args.ygrid) 

z1 = griddata(x,y,z,x1,y1) #genero la griglia (interpola se necessario)


################  3 modi differenti per generare la mappa 2d  #######################################
#####################################################################################################


#Metodo 1: contourf
if args.maxf: levels = range(int(minz),int(args.maxf)+1,cnt_level)
else: levels = range(int(minz),int(max(z))+1,cnt_level)
CS = plt.contourf(x1,y1,z1,levels,cmap=colormap,antialiased=True)

ax = plt.gca()
for tick in ax.xaxis.get_major_ticks():
    tick.label1.set_fontsize(tickfsize)

# artificially overwrite the value to set the range: [0,1]
#plt.xticks([0,12,24,36,48,60])
#ax.set_xticklabels( [0,0.2,0.4,0.6,0.8,1] )
#plt.yticks([0,12,24,36,48,60])
#ax.set_yticklabels( [0,0.2,0.4,0.6,0.8,1] )

for tick in ax.yaxis.get_major_ticks():
    tick.label1.set_fontsize(tickfsize)

# draw contour lines
CS2 = plt.contour(x1,y1,z1,CS.levels, colors = 'k',hold='on')

# add value to contour line
if cnt_label: plt.clabel(CS2,fmt='%d')


"""
#Metodo 2: pcolor
#CS = plt.pcolor(x1,y1,z1,cmap=plt.cm.jet) #per gli altri argomenti vedi l'help; la risoluzione e' data dal numero di punti

#Metodo 3: imshow 
xstart = int(round(min(x)))
xend = int(round(max(x)))
ystart = int(round(min(y)))
yend =int(round(max(y)))
CS = plt.subplot(111)
# color maps:
# cm.RdYlBu
# cm.jet
im = plt.imshow( z1, aspect='auto', cmap=plt.cm.RdYlBu,extent=(xstart,xend,ystart,yend), origin='lower' ) 
#im.set_interpolation('bilinear') #alternativamente si puo' fornire il metodo di interpolazione come argomento di imshow(interpolation='whatever')
#im.set_interpolation('bicubic')
#im.set_interpolation('nearest')
"""
#####################################################################################################
#####################################################################################################

# Generate ticks for color bar
start = int(round(min(z)))
if args.maxf: end = int(round(args.maxf)-0.5)
else: end = int(round(max(z)) - 0.5)
mticks = [i for i in range(start,end,cbar_ticks)]

if cbar_draw:
	# plot colorbar
	cbar = plt.colorbar(CS,ticks=mticks, format='%d')
	cbar.set_label(cbar_label,fontsize=fsize)

# plot grid
if draw_grid: plt.grid()

#plt.rc('legend',**{'fontsize':12})

# axis labels and title
if args.tit: plt.title(args.tit,fontsize=fsize)
if args.xlab: plt.xlabel(args.xlab,fontsize=fsize)
if args.ylab: plt.ylabel(args.ylab,fontsize=fsize)


####################################Salva un'immagine################################################
#plt.savefig('fes.ps',format='ps')
#plt.savefig('fes.png', dpi=300)

if args.out: plt.savefig(args.out, dpi=300)
else: plt.savefig(args.fes+'.pdf', dpi=300)
#####################################################################################################

if not args.noshow: plt.show()
