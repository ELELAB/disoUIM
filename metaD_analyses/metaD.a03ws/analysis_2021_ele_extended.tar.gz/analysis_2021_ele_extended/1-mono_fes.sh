cvnum=2 #helicity
hillsfile=HILLS
totcvs=2
stride=10000
nproc=4
mpirun -np $nproc /usr/local/sum_hills/parallel/sum_hills.mpi.x -f $hillsfile -out fes.dat -stride $stride -ndim $totcvs -ndw $cvnum -kt 2.5 
