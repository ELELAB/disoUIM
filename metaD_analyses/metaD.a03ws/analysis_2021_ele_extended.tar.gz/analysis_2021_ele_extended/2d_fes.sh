cvnum=1
cvnum2=2
hillsfile=HILLS
totcvs=2
stride=1000
nproc=4
mpirun -np $nproc /usr/local/sum_hills/parallel/sum_hills_mpi.x -f $hillsfile -out fes.dat -stride $stride -ndim $totcvs -ndw $cvnum $cvnum2 -kt 2.5 
