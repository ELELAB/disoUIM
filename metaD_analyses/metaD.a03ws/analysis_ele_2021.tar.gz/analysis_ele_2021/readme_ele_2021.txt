#run sumhills first on cv2
sh 1-mono_fes.sh
#run analyze_FES to get the ddGs estimate
#./analyze_FES.sh NFES minA maxA minB maxB KBT
#we have two states one < 15 and one > 15 
./analyze_FES.sh 63  0 16 16 45 2.5 > ab_dGvstime.txt
#to plot the results one could use the gnuplot script in the folder plot_dGs.pnl
#or any other tool for figure preparation - remember to convert kj/mol to kcal/mol in the process
